Spustenie:
Vytvorenie virtualneho prostredia: python3 -m venv .venv
Aktivacia virtualneho prostredia: source .venv/bin/activate
Instalacia balickov: pip install -r requirements.txt
Spustenie servera: make run TYPE=s PORT=54321
Spustenie clienta: make run TYPE=c PORT=54321